// Package mid contains the set of middleware functions.
package mid
